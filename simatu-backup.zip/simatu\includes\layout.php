<?php
require_once __DIR__ . '/config.php';

function renderHeader(string $pageTitle = '', string $activePage = ''): void {

    $user  = currentUser();
    $flash = flashGet();

    /*
    |--------------------------------------------------------------------------
    | USER INITIAL
    |--------------------------------------------------------------------------
    */

    $initials = 'U';

    if (!empty($user['full_name'])) {

        $parts = explode(' ', trim($user['full_name']));

        $initials = strtoupper(
            substr($parts[0], 0, 1) .
            (isset($parts[1]) ? substr($parts[1], 0, 1) : '')
        );
    }

?>
<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>

        <?= sanitize($pageTitle) ?>
        —
        <?= APP_NAME ?>

    </title>

    <!-- BOOTSTRAP -->

    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

    <!-- ICON -->

    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- FONT -->

    <link rel="preconnect"
          href="https://fonts.googleapis.com">

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet">

    <!-- STYLE -->

    <link rel="stylesheet"
          href="<?= BASE_PATH ?>/assets/css/style.css">

    <!-- CHART -->

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

/* ======================================================
   BODY
====================================================== */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Inter',sans-serif;
    background:#f1f5f9;
    overflow-x:hidden;
}

/* ======================================================
   APP
====================================================== */

.app-wrapper{
    display:flex;
    width:100%;
}

/* ======================================================
   SIDEBAR PREMIUM
====================================================== */

.sidebar{
    width:280px;
    min-height:100vh;
    background:
        linear-gradient(180deg,#0b1120 0%,#111827 100%);
    position:fixed;
    top:0;
    left:0;
    z-index:999;
    overflow-y:auto;
    display:flex;
    flex-direction:column;
    box-shadow:
        0 0 30px rgba(0,0,0,.18);

    padding-bottom:100px;
}

/* ======================================================
   BRAND
====================================================== */

.sidebar-brand{
    padding:24px 18px 20px;
    border-bottom:1px solid rgba(255,255,255,.06);
    background:
        linear-gradient(180deg,
        rgba(255,255,255,.03),
        rgba(255,255,255,0));
}

/* ======================================================
   LOGO
====================================================== */

.brand-logo-full{
    width:100%;
    display:flex;
    justify-content:center;
    align-items:center;
}

.brand-logo-full img{
    width:215px;
    max-width:100%;
    object-fit:contain;
    transition:.3s;
    filter:
        drop-shadow(0 8px 20px rgba(37,99,235,.25));
}

.brand-logo-full img:hover{
    transform:scale(1.02);
}

/* ======================================================
   NAVIGATION
====================================================== */

.sidebar-nav{
    padding:18px 14px;
    flex:1;
}

.nav-section{
    color:#94a3b8;
    font-size:11px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:1.2px;
    margin:26px 12px 10px;
}

.nav-item{
    display:flex;
    align-items:center;
    gap:14px;
    padding:14px 16px;
    border-radius:16px;
    color:#dbeafe;
    text-decoration:none;
    transition:.25s ease;
    margin-bottom:8px;
    font-size:14px;
    font-weight:600;
    position:relative;
    overflow:hidden;
}

.nav-item i{
    font-size:18px;
}

.nav-item:hover{
    background:rgba(255,255,255,.06);
    color:#fff;
    transform:translateX(4px);
}

.nav-item.active{
    background:
        linear-gradient(135deg,#2563eb,#1d4ed8);
    color:#fff;
    box-shadow:
        0 10px 25px rgba(37,99,235,.35);
}

.nav-item.active::before{
    content:'';
    position:absolute;
    left:0;
    top:0;
    width:4px;
    height:100%;
    background:#fff;
}

/* ======================================================
   FOOTER
====================================================== */

.sidebar-footer{
    padding:20px;
    border-top:1px solid rgba(255,255,255,.06);
    background:
        rgba(255,255,255,.02);
}

.user-info{
    display:flex;
    align-items:center;
    gap:12px;
}

.user-avatar{
    width:48px;
    height:48px;
    border-radius:50%;
    background:
        linear-gradient(135deg,#3b82f6,#2563eb);
    display:flex;
    align-items:center;
    justify-content:center;
    color:#fff;
    font-weight:700;
    font-size:18px;
    box-shadow:
        0 8px 18px rgba(37,99,235,.35);
}

.user-details{
    flex:1;
}

.user-name{
    color:#fff;
    font-weight:700;
    font-size:14px;
    line-height:1.2;
}

.user-role{
    color:#94a3b8;
    font-size:12px;
    margin-top:3px;
}

.logout-btn{
    width:44px;
    height:44px;
    border-radius:14px;
    background:
        linear-gradient(135deg,#ef4444,#dc2626);
    display:flex;
    align-items:center;
    justify-content:center;
    color:#fff;
    text-decoration:none;
    margin-top:16px;
    transition:.25s;
    box-shadow:
        0 8px 18px rgba(239,68,68,.25);
}

.logout-btn:hover{
    transform:translateY(-2px);
    color:#fff;
}

/* ======================================================
   MAIN
====================================================== */

.main-content{
    margin-left:280px;
    width:calc(100% - 280px);
    min-height:100vh;
    background:#f8fafc;
}

/* ======================================================
   TOPBAR
====================================================== */

.topbar{
    height:76px;
    background:#fff;
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 30px;
    border-bottom:1px solid #e2e8f0;
    position:sticky;
    top:0;
    z-index:100;
}

.sidebar-toggle{
    border:none !important;
    background:#eff6ff !important;
    color:#2563eb !important;
    width:42px;
    height:42px;
    border-radius:12px;
    display:flex;
    align-items:center;
    justify-content:center;
}

.sidebar-toggle i{
    font-size:22px;
}

.topbar-org{
    font-weight:600;
    color:#0f172a;
    font-size:14px;
}

.topbar-user{
    display:flex;
    align-items:center;
    gap:12px;
    font-weight:600;
    color:#0f172a;
}

.topbar-avatar{
    width:42px;
    height:42px;
    border-radius:50%;
    background:
        linear-gradient(135deg,#2563eb,#1d4ed8);
    color:#fff;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:14px;
    font-weight:700;
}

/* ======================================================
   PAGE
====================================================== */

.page-content{
    padding:30px;
}

/* ======================================================
   ALERT
====================================================== */

.alert{
    border:none;
    border-radius:16px;
    padding:16px 18px;
    font-weight:500;
    box-shadow:
        0 5px 15px rgba(0,0,0,.04);
}

/* ======================================================
   SCROLLBAR
====================================================== */

.sidebar::-webkit-scrollbar{
    width:6px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:rgba(255,255,255,.15);
    border-radius:20px;
}

/* ======================================================
   MOBILE
====================================================== */

@media(max-width:992px){

    .sidebar{
        left:-100%;
        transition:.35s;
    }

    .sidebar.show{
        left:0;
    }

    .main-content{
        margin-left:0;
        width:100%;
    }

    .topbar{
        padding:0 18px;
    }

    .page-content{
        padding:20px;
    }

}

</style>

</head>

<body>

<div class="app-wrapper">

    <!-- ===================================================== -->
    <!-- SIDEBAR -->
    <!-- ===================================================== -->

    <aside class="sidebar"
           id="sidebar">

        <!-- ===================================================== -->
        <!-- BRAND -->
        <!-- ===================================================== -->

        <div class="sidebar-brand">

            <div class="brand-logo-full">

                <img src="<?= BASE_PATH ?>/assets/img/simatu.png"
                     alt="SIMATU Logo"
                     onerror="this.src='https://via.placeholder.com/220x70?text=SIMATU';">

            </div>

        </div>

        <!-- ===================================================== -->
        <!-- NAVIGATION -->
        <!-- ===================================================== -->

        <nav class="sidebar-nav">

            <!-- DASHBOARD -->

            <a href="<?= BASE_PATH ?>/dashboard.php"
               class="nav-item <?= $activePage === 'dashboard' ? 'active' : '' ?>">

                <i class="bi bi-grid-1x2-fill"></i>

                <span>Dashboard</span>

            </a>
<!-- PERSDIAAN -->

<div class="nav-section">

    Persediaan Barang

</div>

<a href="<?= BASE_PATH ?>/persediaan/stock.php"
   class="nav-item <?= $activePage === 'persediaan-stock' ? 'active' : '' ?>">

    <i class="bi bi-box-seam-fill"></i>

    <span>Stock Barang</span>

</a>

<a href="<?= BASE_PATH ?>/persediaan/masuk.php"
   class="nav-item <?= $activePage === 'persediaan-masuk' ? 'active' : '' ?>">

    <i class="bi bi-box-arrow-in-down"></i>

    <span>Barang Masuk</span>

</a>

<a href="<?= BASE_PATH ?>/persediaan/keluar.php"
   class="nav-item <?= $activePage === 'persediaan-keluar' ? 'active' : '' ?>">

    <i class="bi bi-box-arrow-up"></i>

    <span>Barang Keluar</span>

</a>

            <!-- BMN -->

            <div class="nav-section">

                BMN

            </div>

            <a href="<?= BASE_PATH ?>/bmn/index.php"
               class="nav-item <?= $activePage === 'bmn-bergerak' ? 'active' : '' ?>">

                <i class="bi bi-truck-front-fill"></i>

                <span>Barang Bergerak</span>

            </a>

            <a href="<?= BASE_PATH ?>/bmn/tidak_bergerak.php"
               class="nav-item <?= $activePage === 'bmn-tidak-bergerak' ? 'active' : '' ?>">

                <i class="bi bi-building-fill"></i>

                <span>Barang Tidak Bergerak</span>

            </a>

            <a href="<?= BASE_PATH ?>/bmn/laporan.php"
               class="nav-item <?= $activePage === 'bmn-laporan' ? 'active' : '' ?>">

                <i class="bi bi-file-earmark-bar-graph-fill"></i>

                <span>Laporan BMN</span>

            </a>

            <!-- KEUANGAN -->

            <div class="nav-section">

                Keuangan

            </div>

            <a href="<?= BASE_PATH ?>/keuangan/index.php"
               class="nav-item <?= $activePage === 'keuangan' ? 'active' : '' ?>">

                <i class="bi bi-cash-coin"></i>

                <span>Keuangan</span>

            </a>

            <!-- PEGAWAI -->

            <div class="nav-section">

                Kepegawaian

            </div>

            <a href="<?= BASE_PATH ?>/kepegawaian/index.php"
               class="nav-item <?= $activePage === 'kepegawaian' ? 'active' : '' ?>">

                <i class="bi bi-people-fill"></i>

                <span>Data Pegawai</span>

            </a>

            <a href="<?= BASE_PATH ?>/kepegawaian/kenaikan_pangkat.php"
               class="nav-item <?= $activePage === 'kepegawaian-kp' ? 'active' : '' ?>">

                <i class="bi bi-arrow-up-circle-fill"></i>

                <span>Kenaikan Pangkat</span>

            </a>

            <!-- PROFILE -->

            <div class="nav-section">

                Account

            </div>

          <a href="<?= BASE_PATH ?>/profile/index.php"
               class="nav-item <?= $activePage === 'profile' ? 'active' : '' ?>">

                <i class="bi bi-person-circle"></i>

                <span>Profile</span>

            </a>

        </nav>

        <!-- ===================================================== -->
        <!-- FOOTER -->
        <!-- ===================================================== -->

        <div class="sidebar-footer">

            <div class="user-info">

                <div class="user-avatar">

                    <?= $initials ?>

                </div>

                <div class="user-details">

                    <div class="user-name">

                        <?= sanitize($user['full_name'] ?? 'Administrator') ?>

                    </div>

                    <div class="user-role">

                        <?= ucfirst($user['role'] ?? 'admin') ?>

                    </div>

                </div>

            </div>

            <a href="<?= BASE_PATH ?>/logout.php"
               class="logout-btn"
               title="Logout">

                <i class="bi bi-box-arrow-right"></i>

            </a>

        </div>

    </aside>

    <!-- ===================================================== -->
    <!-- MAIN -->
    <!-- ===================================================== -->

    <main class="main-content">

        <!-- TOPBAR -->

        <header class="topbar">

            </button>

            <div class="topbar-org">

                <i class="bi bi-geo-alt-fill"></i>

                <?= APP_ORG ?>

            </div>

            <div class="topbar-user">

                <div class="topbar-avatar">

                    <?= $initials ?>

                </div>

                <div>

                   <?= sanitize($user['full_name'] ?? '') ?>

                </div>

            </div>

        </header>

        <!-- CONTENT -->

        <div class="page-content">

            <!-- FLASH -->

            <?php if ($flash): ?>

                <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">

                    <?= sanitize($flash['message']) ?>

                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="alert"></button>

                </div>

            <?php endif; ?>

<?php
}

function renderFooter(): void {
?>

        </div>

    </main>

</div>

<!-- JS -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>

const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar       = document.getElementById('sidebar');

if(sidebarToggle){

    sidebarToggle.addEventListener('click', function(){

        sidebar.classList.toggle('show');

    });

}

</script>

</body>
</html>

<?php
}
?>