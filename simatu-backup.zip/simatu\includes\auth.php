<?php
require_once __DIR__ . '/db.php';

class Auth {
    public static function login(string $username, string $password): bool {
        $user = Database::fetch(
            'SELECT * FROM users WHERE (username = ? OR email = ?) AND 1=1',
            [$username, $username]
        );

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user'] = [
                'id'        => $user['id'],
                'full_name' => $user['full_name'],
                'email'     => $user['email'],
                'username'  => $user['username'],
                'role'      => $user['role'],
            ];
            return true;
        }
        return false;
    }

    public static function register(string $fullName, string $email, string $username, string $password): bool|string {
        $existing = Database::fetch('SELECT id FROM users WHERE email = ? OR username = ?', [$email, $username]);
        if ($existing) {
            return 'Email atau username sudah digunakan.';
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        Database::execute(
            'INSERT INTO users (full_name, email, username, password) VALUES (?, ?, ?, ?)',
            [$fullName, $email, $username, $hash]
        );
        return true;
    }

    public static function logout(): void {
        session_destroy();
    }
}
