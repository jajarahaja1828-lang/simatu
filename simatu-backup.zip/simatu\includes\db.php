<?php

require_once __DIR__ . '/config.php';

class Database
{
    private static ?PDO $instance = null;

    /*
    |--------------------------------------------------------------------------
    | CONNECTION
    |--------------------------------------------------------------------------
    */

    public static function getInstance(): PDO
    {
        if (self::$instance === null) {

            $dsn =
                "mysql:host=" . DB_HOST .
                ";port=" . DB_PORT .
                ";dbname=" . DB_NAME .
                ";charset=utf8mb4";

            try {

                self::$instance = new PDO(
                    $dsn,
                    DB_USER,
                    DB_PASS,
                    [
                        PDO::ATTR_ERRMODE =>
                            PDO::ERRMODE_EXCEPTION,

                        PDO::ATTR_DEFAULT_FETCH_MODE =>
                            PDO::FETCH_ASSOC,

                        PDO::ATTR_EMULATE_PREPARES =>
                            false,
                    ]
                );

            } catch (PDOException $e) {

                die(
                    '<div style="
                        padding:40px;
                        font-family:Arial;
                    ">
                        <h2 style="color:red">
                            Database Connection Error
                        </h2>

                        <p>' .
                        htmlspecialchars(
                            $e->getMessage()
                        ) .
                        '</p>
                    </div>'
                );
            }
        }

        return self::$instance;
    }

    /*
    |--------------------------------------------------------------------------
    | QUERY
    |--------------------------------------------------------------------------
    */

    public static function query(
        string $sql,
        array $params = []
    ): PDOStatement {

        $stmt =
            self::getInstance()->prepare($sql);

        $stmt->execute($params);

        return $stmt;
    }

    /*
    |--------------------------------------------------------------------------
    | FETCH SINGLE
    |--------------------------------------------------------------------------
    */

    public static function fetch(
        string $sql,
        array $params = []
    ): ?array {

        $result =
            self::query(
                $sql,
                $params
            )->fetch();

        return $result ?: null;
    }

    /*
    |--------------------------------------------------------------------------
    | FETCH ALL
    |--------------------------------------------------------------------------
    */

    public static function fetchAll(
        string $sql,
        array $params = []
    ): array {

        return self::query(
            $sql,
            $params
        )->fetchAll();
    }

    /*
    |--------------------------------------------------------------------------
    | EXECUTE
    |--------------------------------------------------------------------------
    */

    public static function execute(
        string $sql,
        array $params = []
    ): int {

        return self::query(
            $sql,
            $params
        )->rowCount();
    }

    /*
    |--------------------------------------------------------------------------
    | INSERT ID
    |--------------------------------------------------------------------------
    */

    public static function lastInsertId(): string
    {
        return self::getInstance()
            ->lastInsertId();
    }

    /*
    |--------------------------------------------------------------------------
    | BEGIN TRANSACTION
    |--------------------------------------------------------------------------
    */

    public static function beginTransaction(): bool
    {
        return self::getInstance()
            ->beginTransaction();
    }

    /*
    |--------------------------------------------------------------------------
    | COMMIT
    |--------------------------------------------------------------------------
    */

    public static function commit(): bool
    {
        return self::getInstance()
            ->commit();
    }

    /*
    |--------------------------------------------------------------------------
    | ROLLBACK
    |--------------------------------------------------------------------------
    */

    public static function rollBack(): bool
    {
        return self::getInstance()
            ->rollBack();
    }
}