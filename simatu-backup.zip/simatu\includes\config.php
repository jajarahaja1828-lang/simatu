<?php

/*
|--------------------------------------------------------------------------
| DATABASE
|--------------------------------------------------------------------------
*/

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'simatu');
define('DB_USER', 'root');
define('DB_PASS', '');

/*
|--------------------------------------------------------------------------
| APPLICATION
|--------------------------------------------------------------------------
*/

define('APP_NAME', 'SIMATU');

define(
    'APP_FULL_NAME',
    'Sistem Management Tata Usaha'
);

define(
    'APP_ORG',
    'Balai Pemasyarakatan Kelas I Jakarta Selatan'
);

define('APP_VERSION', '1.0.0');

/*
|--------------------------------------------------------------------------
| BASE URL
|--------------------------------------------------------------------------
*/

define('BASE_URL', 'http://localhost/simatu/public');

define('BASE_PATH', '/simatu/public');

/*
|--------------------------------------------------------------------------
| TIMEZONE
|--------------------------------------------------------------------------
*/

date_default_timezone_set('Asia/Jakarta');

/*
|--------------------------------------------------------------------------
| SESSION
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {

    session_start();
}

/*
|--------------------------------------------------------------------------
| ERROR REPORTING
|--------------------------------------------------------------------------
| Tambahan agar error mudah diketahui
|--------------------------------------------------------------------------
*/

error_reporting(E_ALL);
ini_set('display_errors', 1);

/*
|--------------------------------------------------------------------------
| ROOT PATH
|--------------------------------------------------------------------------
| Tambahan agar semua file mudah dipanggil
|--------------------------------------------------------------------------
*/

define('ROOT_PATH', dirname(__DIR__));

/*
|--------------------------------------------------------------------------
| ASSET URL
|--------------------------------------------------------------------------
| Tambahan untuk css/js/image
|--------------------------------------------------------------------------
*/

define('ASSET_URL', BASE_URL . '/assets');

/*
|--------------------------------------------------------------------------
| UPLOAD PATH
|--------------------------------------------------------------------------
| Tambahan folder upload
|--------------------------------------------------------------------------
*/

define('UPLOAD_PATH', ROOT_PATH . '/public/uploads');

/*
|--------------------------------------------------------------------------
| AUTO CREATE UPLOAD FOLDER
|--------------------------------------------------------------------------
*/

if (!file_exists(UPLOAD_PATH)) {

    mkdir(UPLOAD_PATH, 0777, true);
}

/*
|--------------------------------------------------------------------------
| REDIRECT
|--------------------------------------------------------------------------
*/

function redirect(string $path): void
{
    header('Location: ' . BASE_URL . $path);
    exit;
}

/*
|--------------------------------------------------------------------------
| URL HELPER
|--------------------------------------------------------------------------
| Tambahan agar link otomatis benar
|--------------------------------------------------------------------------
*/

function url(string $path = ''): string
{
    return BASE_PATH . '/' . ltrim($path, '/');
}

/*
|--------------------------------------------------------------------------
| ASSET HELPER
|--------------------------------------------------------------------------
*/

function asset(string $path = ''): string
{
    return ASSET_URL . '/' . ltrim($path, '/');
}

/*
|--------------------------------------------------------------------------
| LOGIN
|--------------------------------------------------------------------------
*/

function isLoggedIn(): bool
{
    return !empty($_SESSION['user_id']);
}

function requireLogin(): void
{
    if (!isLoggedIn()) {

        redirect('/login.php');
    }
}

/*
|--------------------------------------------------------------------------
| CURRENT USER
|--------------------------------------------------------------------------
*/

function currentUser(): array
{
    return $_SESSION['user'] ?? [];
}

/*
|--------------------------------------------------------------------------
| SANITIZE
|--------------------------------------------------------------------------
*/

if (!function_exists('sanitize')) {

    function sanitize(
        ?string $str
    ): string {

        return htmlspecialchars(
            trim($str ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

/*
|--------------------------------------------------------------------------
| FORMAT
|--------------------------------------------------------------------------
*/

function formatRupiah(
    float $amount
): string {

    return 'Rp ' .
        number_format(
            $amount,
            0,
            ',',
            '.'
        );
}

function formatNumber(
    int $number
): string {

    return number_format(
        $number,
        0,
        ',',
        '.'
    );
}

/*
|--------------------------------------------------------------------------
| FORMAT TANGGAL
|--------------------------------------------------------------------------
| Tambahan format tanggal Indonesia
|--------------------------------------------------------------------------
*/

function formatTanggal($tanggal): string
{
    if (empty($tanggal)) {
        return '-';
    }

    return date('d/m/Y', strtotime($tanggal));
}

/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

function csrf(): string
{
    if (
        empty($_SESSION['csrf_token'])
    ) {

        $_SESSION['csrf_token'] =
            bin2hex(
                random_bytes(32)
            );
    }

    return $_SESSION['csrf_token'];
}

function verifyCsrf(): bool
{
    return isset(
        $_POST['csrf_token']
    ) && hash_equals(
        $_SESSION['csrf_token'] ?? '',
        $_POST['csrf_token']
    );
}

/*
|--------------------------------------------------------------------------
| FLASH MESSAGE
|--------------------------------------------------------------------------
*/

function flashSet(
    string $type,
    string $message
): void {

    $_SESSION['flash'] = [
        'type'    => $type,
        'message' => $message
    ];
}

function flashGet(): ?array
{
    if (isset($_SESSION['flash'])) {

        $flash =
            $_SESSION['flash'];

        unset($_SESSION['flash']);

        return $flash;
    }

    return null;
}

/*
|--------------------------------------------------------------------------
| SUCCESS MESSAGE
|--------------------------------------------------------------------------
| Tambahan helper notifikasi
|--------------------------------------------------------------------------
*/

function success(string $message): void
{
    flashSet('success', $message);
}

function error(string $message): void
{
    flashSet('danger', $message);
}

/*
|--------------------------------------------------------------------------
| DEBUG HELPER
|--------------------------------------------------------------------------
*/

function dd($data)
{
    echo '<pre>';
    print_r($data);
    echo '</pre>';
    die;
}

/*
|--------------------------------------------------------------------------
| FILE UPLOAD HELPER
|--------------------------------------------------------------------------
*/

function uploadFile(array $file, string $folder = ''): ?string
{
    if (empty($file['name'])) {
        return null;
    }

    $targetFolder = UPLOAD_PATH;

    if (!empty($folder)) {

        $targetFolder .= '/' . trim($folder, '/');

        if (!file_exists($targetFolder)) {

            mkdir($targetFolder, 0777, true);
        }
    }

    $extension = pathinfo(
        $file['name'],
        PATHINFO_EXTENSION
    );

    $filename =
        time() .
        '_' .
        uniqid() .
        '.' .
        $extension;

    $destination =
        $targetFolder .
        '/' .
        $filename;

    if (
        move_uploaded_file(
            $file['tmp_name'],
            $destination
        )
    ) {

        return $filename;
    }

    return null;
}

/*
|--------------------------------------------------------------------------
| DELETE FILE HELPER
|--------------------------------------------------------------------------
*/

function deleteFile(string $filename, string $folder = ''): bool
{
    if (empty($filename)) {
        return false;
    }

    $path = UPLOAD_PATH;

    if (!empty($folder)) {
        $path .= '/' . trim($folder, '/');
    }

    $fullPath = $path . '/' . $filename;

    if (file_exists($fullPath)) {

        return unlink($fullPath);
    }

    return false;
}